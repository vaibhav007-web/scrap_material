package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Driver_details extends AppCompatActivity {
    ListView lv;
    ArrayList<String> ar=new ArrayList<String>();
    ArrayList<String>ids=new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drivers_list);
        Intent intent = getIntent();
        String str = intent.getStringExtra("id");

        lv=(ListView)findViewById(R.id.list);

        DatabaseHandler dbh=new DatabaseHandler(Driver_details.this);
        SQLiteDatabase sdb=dbh.getReadableDatabase();

        Cursor c=sdb.rawQuery("select * from user_account1 where id="+str.toString()+"",null);


        if(c.moveToFirst())
        {
            ar.add("DRIVER  DETAILS HERE.....");

            do {
                ids.add(c.getString(0));

                ar.add("\n Name: \n"+c.getString(1));
                ar.add("\n Email: \n "+c.getString(2));
                ar.add("\n Password:\n"+c.getString(3));
                ar.add("\n Contact No:\n"+c.getString(4));
            }while(c.moveToNext());
        }
        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.support_simple_spinner_dropdown_item, ar);
        lv.setAdapter(adapter);


    }
    }
