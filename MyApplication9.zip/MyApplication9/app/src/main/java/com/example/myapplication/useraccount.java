package com.example.myapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class useraccount extends AppCompatActivity {

    EditText edname,edpasswords,edemail,editeco;
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_account);

        edname=(EditText)findViewById(R.id.editName);
        edpasswords=(EditText)findViewById(R.id.editPass);
        edemail=(EditText)findViewById(R.id.editEmail);
        editeco=(EditText)findViewById(R.id.editcontact);

        b1=(Button) findViewById(R.id.buttonAcount);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    String name = edname.getText().toString();
                    String pass = edpasswords.getText().toString();
                    String mail = edemail.getText().toString();
                    String contact = editeco.getText().toString();
                    DatabaseHandler dbh = new DatabaseHandler(useraccount.this);
                    SQLiteDatabase sdb = dbh.getWritableDatabase();
                    ContentValues cv = new ContentValues();
                    cv.put("name", name);
                    cv.put("email", mail);
                    cv.put("passwords", pass);
                    cv.put("contactno", contact);

                    sdb.insert("user_account1", null, cv);


                    Toast.makeText(useraccount.this, "Account Creation Successfully", Toast.LENGTH_LONG).show();

                }
                catch(Exception ex)
                {
                    Toast.makeText(useraccount.this, ""+ex.getMessage(), Toast.LENGTH_LONG).show();
                }

            }
        });




    }
}