package com.example.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseHandler  extends SQLiteOpenHelper {
    public DatabaseHandler(Context context) {
        super(context, "scraps.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table  user_account1(id integer primary key AUTOINCREMENT,name text,email text,passwords text,contactno text);");

        //db.execSQL("insert into admin_login(name,passwords)values('admin','123')");
        db.execSQL("create table    waste_matrial(id integer primary key AUTOINCREMENT,name text,address text,contactno text,quantity text,status integer default 0,date_created datetime default current_timestamp,dname text default 'blank');");

        db.execSQL("create table   assign_driver(id integer primary key AUTOINCREMENT,dname text,address text,contactno text,quantity text);");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {





    }
}