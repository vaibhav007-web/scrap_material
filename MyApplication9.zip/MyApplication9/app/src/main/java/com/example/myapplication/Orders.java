package com.example.myapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Orders  extends AppCompatActivity {


    EditText edname,equantity,edaddress,editeco;
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.orders);

        edname=(EditText)findViewById(R.id.editName);
        equantity=(EditText)findViewById(R.id.editPass);
        edaddress=(EditText)findViewById(R.id.editEmail);
        editeco=(EditText)findViewById(R.id.editcontact);

        b1=(Button) findViewById(R.id.buttonAcount);
        b2=(Button) findViewById(R.id.buttoninbox);
        Intent intent = getIntent();
        String str = intent.getStringExtra("names");


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent ii=new Intent(Orders.this,Item_List.class);

                startActivity(ii);
            }
        });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    String name = edname.getText().toString();
                    String quantity = equantity.getText().toString();
                    String address = edaddress.getText().toString();
                    String contact = editeco.getText().toString();
                    DatabaseHandler dbh = new DatabaseHandler(Orders.this);
                    SQLiteDatabase sdb = dbh.getWritableDatabase();
                    ContentValues cv = new ContentValues();
                    cv.put("name", name);
                    cv.put("address", address);
                    cv.put("quantity", quantity);
                    cv.put("contactno", contact);

                    sdb.insert("waste_matrial", null, cv);


                    Toast.makeText(Orders.this, "Order Added", Toast.LENGTH_LONG).show();

                }
                catch(Exception ex)
                {
                    Toast.makeText(Orders.this, ""+ex.getMessage(), Toast.LENGTH_LONG).show();
                }

            }
        });

    }
    }
