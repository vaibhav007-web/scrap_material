package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Adminview_Order  extends AppCompatActivity {
    ListView lv;
    ArrayList<String> ar=new ArrayList<String>();
    ArrayList<String> ids=new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adminview_order);

        lv=(ListView) findViewById(R.id.li);
        DatabaseHandler dbh=new DatabaseHandler(Adminview_Order.this);
        SQLiteDatabase sdb=dbh.getWritableDatabase();
        Cursor c=sdb.rawQuery("select * from waste_matrial where status='0'",null);

        ar.add("ORDER LIST HERE.....");
        if(c.moveToFirst())
        {
            ids.add(c.getString(0));
            do {
                ids.add(c.getString(0));

                ar.add(c.getString(1)+": ("+c.getString(3)+")");
            }while(c.moveToNext());
        }
        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.support_simple_spinner_dropdown_item, ar);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String s=ids.get(position);
                Toast.makeText(Adminview_Order.this,"Selected Driver"+s,Toast.LENGTH_LONG).show();


                Intent intent = new Intent(getApplicationContext(), Order_details.class);
                intent.putExtra("id", s);
                startActivity(intent);
            }
        });

    }}