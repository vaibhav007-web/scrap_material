package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class driverlists  extends AppCompatActivity {
ListView lv;
ArrayList<String>ar=new ArrayList<String>();
ArrayList<String>ids=new ArrayList<String>();


        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drivers_list);

        lv=(ListView)findViewById(R.id.list);
    registerForContextMenu(lv);
        DatabaseHandler dbh=new DatabaseHandler(driverlists.this);
        SQLiteDatabase sdb=dbh.getReadableDatabase();

        Cursor c=sdb.rawQuery("select * from user_account1",null);

ar.add("DRIVER NAME LIST HERE.....");
        if(c.moveToFirst())
        {
            ids.add(c.getString(0));
            do {
                ids.add(c.getString(0));
                ar.add(c.getString(1)+": ("+c.getString(4)+")");
            }while(c.moveToNext());
        }

        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.support_simple_spinner_dropdown_item, ar);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String s=ids.get(position);
                Toast.makeText(driverlists.this,"Selected Driver"+s,Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), Driver_details.class);
                intent.putExtra("id", s);
                startActivity(intent);
            }
        });

    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0,0,0,"Choose your Action....");

        menu.add(0,1,1,"Delete");


    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {

        if(item.getTitle().equals("Delete"))
        {
            Toast.makeText(driverlists.this,"Y Are Click On"+item.getTitle(),Toast.LENGTH_LONG).show();
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

                int pos=info.position;
                int id=Integer.parseInt(ids.get(pos));

                DatabaseHandler dbh=new DatabaseHandler(driverlists.this);

                SQLiteDatabase sdb=dbh.getWritableDatabase();

                sdb.execSQL("delete from  user_account1 where id="+id+"");
            ar.remove(pos);
            ArrayAdapter adapter = new ArrayAdapter<String>(this,
                    R.layout.support_simple_spinner_dropdown_item, ar);
            lv.setAdapter(adapter);

        }
        return true;
    }



}
