package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    EditText eduname,password;
    Button b1,b2,b3;
    ListView lv;

    TextView tv;
    ArrayList<String>aa=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eduname = (EditText) findViewById(R.id.editText);
        password = (EditText) findViewById(R.id.editText2);

        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button) findViewById(R.id.buttonuser);

        lv=(ListView) findViewById(R.id.li);
        tv=(TextView) findViewById(R.id.textView);

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iii=new Intent(MainActivity.this,Item_List.class);
                startActivity(iii);;
            }
        });

        aa.add("SCRAP MATRIAL LIST");
        aa.add("STEEL(22 RS PER KG WITH EXTRA PRICE)");
        aa.add("IRON(20 RS PER KG WITH EXTRA PRICE)");
        aa.add("LEAD (12 RS PER KG WITH EXTRA PRICE)");
        aa.add("COPPER (19 RS PER KG WITH EXTRA PRICE)");
        aa.add(" STAINLESS STEEL AND ZINC(21 RS PER KG WITH EXTRA PRICE)");
        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.support_simple_spinner_dropdown_item, aa);
        lv.setAdapter(adapter);

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii=new Intent(MainActivity.this,Orders.class);
                startActivity(ii);

            }
        });


b2.setOnClickListener(new View.OnClickListener() {
                          @Override
                          public void onClick(View v) {
                              Intent i = new Intent(MainActivity.this,Userlogin.class );


                              startActivity(i);
                          }
                      });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
String username=eduname.getText().toString();
                String passwords=password.getText().toString();

                if(username.equals("") || passwords.equals(""))
                {
                 if(username.equals(""))
                     eduname.setError("Enter Valid UserName");
                    if(password.equals(""))
                        password.setError("Enter Valid Password");

                }

                else {
                    if (username.equals("admin") && passwords.equals("123")) {
                        Intent i = new Intent(MainActivity.this, AdminHome.class);


                        startActivity(i);

                    } else {


                        Toast.makeText(MainActivity.this, "Invalid UserName And Password", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });



    }
}