package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Inbox_details  extends AppCompatActivity {

    ListView lv;
    ArrayList<String> ar=new ArrayList<String>();
    ArrayList<String> ids=new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inbox_details);

        Intent intent = getIntent();
        String str = intent.getStringExtra("id");

        lv=(ListView)findViewById(R.id.list_inbox);

        DatabaseHandler dbh=new DatabaseHandler(Inbox_details.this);
        SQLiteDatabase sdb=dbh.getReadableDatabase();

        Cursor c=sdb.rawQuery("select * from waste_matrial where id="+str.toString()+"",null);


        if(c.moveToFirst())
        {
            ar.add("CUSTOMER  DETAIL HERE.....");

            do {
                ids.add(c.getString(0));

                ar.add("\n Name: \n" + c.getString(1));
                ar.add("\n Address: \n " + c.getString(2));
                ar.add("\n Contact No:\n" + c.getString(3));
                ar.add("\n Quantity:\n" + c.getString(4));

                ar.add("\n Order Date:\n" + c.getString(6));
                ar.add("\n Driver Name:\n" + c.getString(7));

            }while(c.moveToNext());
        }
        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.support_simple_spinner_dropdown_item, ar);
        lv.setAdapter(adapter);


    }
}
