package com.example.myapplication;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Item_List  extends AppCompatActivity {
    ListView lv;


    ArrayList<String> aa=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_list);

        lv=(ListView) findViewById(R.id.list_item);

        aa.add("SCRAP MATRIAL LIST");
        aa.add("STEEL(22 RS PER KG WITH EXTRA PRICE)");
        aa.add("IRON(20 RS PER KG WITH EXTRA PRICE)");
        aa.add("LEAD (12 RS PER KG WITH EXTRA PRICE)");
        aa.add("COPPER (19 RS PER KG WITH EXTRA PRICE)");
        aa.add(" STAINLESS STEEL AND ZINC(21 RS PER KG WITH EXTRA PRICE)");

        aa.add("Plastic Bags(24 RS PER KG WITH EXTRA PRICE)");
        aa.add("Plastic Water Bottles(30 RS PER KG WITH EXTRA PRICE)");
        aa.add("Empty Ice Cream Container(20 RS PER KG WITH EXTRA PRICE)");
        aa.add("Old Clothing(100 RS PER KG WITH EXTRA PRICE)");
        aa.add("Old Paper(11 RS PER KG WITH EXTRA PRICE)");
        aa.add(" Newspapers(9 RS PER KG WITH EXTRA PRICE)");

        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.support_simple_spinner_dropdown_item, aa);
        lv.setAdapter(adapter);
    }
    }
