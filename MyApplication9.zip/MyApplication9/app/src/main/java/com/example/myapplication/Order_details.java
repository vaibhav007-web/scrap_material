package com.example.myapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Order_details  extends AppCompatActivity {

    ListView lv;
    ArrayList<String> ar=new ArrayList<String>();
    ArrayList<String>ids=new ArrayList<String>();
    ArrayList<String>dname=new ArrayList<String>();

Button b1;

    Spinner sp;
    String de_name,de_address,de_contact,de_quantity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_order);
        sp=(Spinner)findViewById(R.id.order_sp);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                de_name=sp.getSelectedItem().toString();
                Toast.makeText(Order_details.this,""+de_name,Toast.LENGTH_LONG).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        b1=(Button) findViewById(R.id.order_btn);

        Intent intent = getIntent();
        String str = intent.getStringExtra("id");

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                DatabaseHandler dbh1 = new DatabaseHandler(Order_details.this);
                SQLiteDatabase sdb1 = dbh1.getReadableDatabase();

                ContentValues cv=new ContentValues();
                cv.put("dname",de_name);
                cv.put("address",de_address);
                cv.put("contactno",de_contact);
                cv.put("quantity",de_quantity);
                sdb1.insert("assign_driver", null, cv);

                SQLiteDatabase sdb2= dbh1.getWritableDatabase();
                sdb2.execSQL("update waste_matrial set status='1',dname='"+de_name+"' where id="+str.toString()+"");


                Toast.makeText(Order_details.this,"Driver Assign Successfully",Toast.LENGTH_LONG).show();

                Intent ii=new Intent(Order_details.this,Adminview_Order.class);
                startActivity(ii);

            }
        });



        DatabaseHandler dbh1 = new DatabaseHandler(Order_details.this);
        SQLiteDatabase sdb1 = dbh1.getReadableDatabase();

        Cursor c1=sdb1.rawQuery("select * from user_account1",null);


        if (c1.moveToFirst()) {
            dname.add("Select Driver Name");

            do {

                dname.add(c1.getString(1));
            } while (c1.moveToNext());
        }
        ArrayAdapter adapter1 = new ArrayAdapter<String>(this,
                R.layout.support_simple_spinner_dropdown_item, dname);
        sp.setAdapter(adapter1);
        //------------------------------

            lv = (ListView) findViewById(R.id.list);


            DatabaseHandler dbh = new DatabaseHandler(Order_details.this);
            SQLiteDatabase sdb = dbh.getReadableDatabase();

            Cursor c = sdb.rawQuery("select * from  waste_matrial where id=" + str.toString() + "", null);


            if (c.moveToFirst()) {
                ar.add("ORDER  DETAILS HERE.....");
                ids.add(c.getString(0));

                do {
                    ids.add(c.getString(0));


                    ar.add("\n Name: \n" + c.getString(1));
                    ar.add("\n Address: \n " + c.getString(2));
                    ar.add("\n Contact No:\n" + c.getString(3));
                    ar.add("\n Quantity:\n" + c.getString(4));

                    ar.add("\n Order Date:\n" + c.getString(6));
                    ar.add("\n Driver Name:\n" + c.getString(7));


                    //Assign data Into The Variable
                   // de_name=c.getString(1);

                    de_address=c.getString(2);
                    de_contact=c.getString(3);
                    de_quantity=c.getString(4);
                } while (c.moveToNext());
            }
            ArrayAdapter adapter = new ArrayAdapter<String>(this,
                    R.layout.support_simple_spinner_dropdown_item, ar);
            lv.setAdapter(adapter);


        }
    }