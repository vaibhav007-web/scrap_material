package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;



public class Userlogin extends AppCompatActivity {
    Button b1,b2;
EditText edname,edpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userlogin);


        b1=(Button)findViewById(R.id.buttons);
     //   b2=(Button)findViewById(R.id.buttons2);

        edname=(EditText)findViewById(R.id.editText);
        edpassword=(EditText)findViewById(R.id.editText2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            String name=edname.getText().toString();
            String pass=edpassword.getText().toString();

            DatabaseHandler dbh=new DatabaseHandler(Userlogin.this);
            SQLiteDatabase sdb=dbh.getReadableDatabase();

                Cursor c=sdb.rawQuery("select * from user_account1",null);
                int count=1;
                if(c.moveToFirst())
                {
                    do{

                        String names=c.getString(1);
                        String password=c.getString(3);
                        if(names.equals(name) && password.equals(pass))
                        {
                            Intent ii=new Intent(Userlogin.this,Inbox.class);
                            ii.putExtra("names",names);
                            startActivity(ii);
                            count=0;
                        }


                    }while(c.moveToNext());
                }
                if(count==1)
                    Toast.makeText(Userlogin.this,"Invalid UserName And Password",Toast.LENGTH_LONG).show();





            }
        });


    }
    }
